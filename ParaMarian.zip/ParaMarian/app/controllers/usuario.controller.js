const Usuario = require("../models/usuario.model.js");

/*
create
findAll
findOne                                                WTF???
update
delete
deleteAll
*/

// Create and Save a new usuario
exports.crearUsuario = (req, res) => {
  
};

// Fi
exports.getTipoUsuario = (req, res) => {
  
};

//
exports.getPassword = (req, res) => {
  
};

// 
exports.validarInicioDeSesion = (req, res) => {
  
};

